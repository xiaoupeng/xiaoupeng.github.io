#!/sbin/sh
#--------------------------------------------
# 作者：一零一二
# 版本：0.1
# 功能：实现华为悦盒IPTV遥控器"本地"键退出应用程序
# 联系方式：qq：64652178
#--------------------------------------------

while [ 1 ]
do
	rm_code=`getevent -c 1 /dev/input/event0`	
	
	if [ "$rm_code" = "0001 00d9 00000001" ] ; then
	   print $rm_code
	   am start -n com.dangbei.tvlauncher/com.dangbei.tvlauncher.IndexActivity
        fi
	
done
		